package com.placementcell.officer.controller;

import java.util.List;
import java.util.Objects;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.placementcell.officer.entity.Company;
import com.placementcell.officer.entity.User;
import com.placementcell.officer.repository.UserRepository;
import com.placementcell.officer.service.CompanyService;

@Controller
public class AppController {

	@Autowired
	private UserRepository repo;

	@Autowired
	private CompanyService service;

//shows hone page (login)

	@GetMapping("")
	public String viewHomePage() {
		return "index";
	}

	@GetMapping("/home")
	public String viewIndexPage() {
		return "Home";
	}

//register page for new user

	@GetMapping("/register")
	public String showRegistrationForm(Model model) {
		model.addAttribute("user", new User());
		return "signup_form";
	}

	// it stores data to database

	@PostMapping("/process_register")
	public String processRegister(User user) {
		BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		String encodedPassword = passwordEncoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		repo.save(user);

		return "register_success";
	}

	// it shows the list of users

	@GetMapping("/list_users")
	public String listUsers(Model model) {
		List<User> listUsers = repo.findAll();
		model.addAttribute("listUsers", listUsers);

		return "users";
	}

	// shows list of company

	@GetMapping("/company")
	public String showCompanyForm(Model model) {
		List<Company> listCompany = service.listAll();
		model.addAttribute("listCompany", listCompany);
		return "company";
	}

	// performs in add company

	@GetMapping("/company_new")
	public String showCompanyNewForm(Model model) {
		model.addAttribute("company", new Company());
		return "company_new";
	}

	// performed as save in add company form

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveCompany(@ModelAttribute("company") Company company) {
		service.save(company);

		return "redirect:/company";
	}

	// edit the company information

	@GetMapping("/edit/{id}")
	public ModelAndView showCompanyEditForm(@PathVariable(name = "id") int id) {
		ModelAndView mav = new ModelAndView("edit_company");
		Company company = service.get(id);
		mav.addObject("company", company);
		return mav;
	}

	// deleting the stored information

	@RequestMapping("/delete/{id}")
	public String deleteCompany(@PathVariable(name = "id") int id) {
		service.delete(id);
		return "redirect:/company";
	}

	@GetMapping("/back")
	public String viewBackPage() {
		return "index";
	}

	@GetMapping("/return")
	public String viewreturnPage() {
		return "redirect:/company";
	}

	@GetMapping("/roll")
	public String viewCompanyPage() {
		return "redirect:/list_users";
	}

}
