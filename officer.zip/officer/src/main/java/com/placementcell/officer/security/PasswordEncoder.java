package com.placementcell.officer.security;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//it performs in to convert password into hash code

public class PasswordEncoder {

	public static void main(String[] args) {
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String rawPassword = "drtgvjh";
		String encodedPassword = encoder.encode(rawPassword);

		System.out.println(encodedPassword);

	}

}
