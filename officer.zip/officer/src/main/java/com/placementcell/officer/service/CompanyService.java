package com.placementcell.officer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.placementcell.officer.entity.Company;
import com.placementcell.officer.repository.CompanyRepository;

@Service
@Transactional
public class CompanyService<Students> {

	@Autowired
	private CompanyRepository srepo;

	// performs CRUD activity (save,delete)

	public List<Company> listAll() {
		return srepo.findAll();
	}

	public void save(Company company) {
		srepo.save(company);
	}

	public Company get(Integer id) {
		return srepo.findById(id).get();
	}

	public void delete(Integer id) {
		srepo.deleteById(id);
	}

}
