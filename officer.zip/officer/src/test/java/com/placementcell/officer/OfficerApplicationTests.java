package com.placementcell.officer;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

import com.placementcell.officer.entity.Company;
import com.placementcell.officer.entity.User;
import com.placementcell.officer.repository.CompanyRepository;
import com.placementcell.officer.repository.UserRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Rollback(false)
public class OfficerApplicationTests {

	@Autowired
	private TestEntityManager testEntityManager;

	@Autowired
	UserRepository userRepository;

	@Autowired
	CompanyRepository companyRepository;

	@Test
	public void testCreateUser() {
		User user = new User();
		user.setFirstName("gor");
		user.setLastName("nisha");
		user.setPassword("sonim1234");
		user.setEmail("nisha@gmail.com");
		User savedUser = userRepository.save(user);

	}

	@Test
	public void testCreateCompany() {
		Company company = new Company();
		company.setCompany_name("IBM");
		company.setEmail("ibm@gmail.com");
		company.setPercentage("75%");
		company.setPosition("Trainee");
		Company savedCompany = companyRepository.save(company);

	}
}